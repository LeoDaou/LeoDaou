<!DOCTYPE html>
<html lang="en">
<?php
session_start();
require('connection/db-info.php');
date_default_timezone_set('Asia/Beirut');
$_SESSION['currentd']=date('Y-m-d');
if((int)substr($_SESSION['currentd'],5,6)=="01"){
	$query=$mysqli->prepare("SELECT date,id,start_time,end_time FROM attendance");
	$query->execute();
	$query->store_result();
	$query->bind_result($date,$id,$start,$end);
	$query2=$mysqli->prepare("TRUNCATE TABLE pastattendance");
	$qeury2->execute();
	while($query->fetch()){
		$query3=$mysqli->prepare("INSERT INTO pastattendance (date,employee_id,start_time,end_time) VALUES(?,?,?,?)");
		$query3->bind_param("siss",$date,$id,$start,$end);
		$query3->execute();
	}
	$query2=$mysqli->prepare("TRUNCATE TABLE attendance");
	$qeury2->execute();
}
if(isset($_SESSION['user_log'])&&$_SESSION['user_log']==true)
	header('Location:home/user_login');
if(isset($_SESSION['logged_in1'])&&$_SESSION['logged_in1']==true)
	header('Location:home/');


?>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Welcome HR</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/coming-soon.min.css" rel="stylesheet">

  </head>

  <body style="background: url(https://www.rd.com/wp-content/uploads/2018/02/43_Walmart_Surprisingly-Simple-Ways-to-Save-BIG-at-the-Supermarket_186861932_Ken-Wolter-760x506.jpg) ; background-size: 100% 100%;">


    <div class="masthead">
      <div class="masthead-bg"></div>
      <div class="container h-100">
        <div class="row h-100">
          <div class="col-12 my-auto">
            <div class="masthead-content text-white text-center">
              <h1 class="mb-3">Welcome HR!</h1>
			  
              <form class="login" action="login.php" method="POST">
			  <div class="form-row">
			  <div class="col-12 input-group input-group-newsletter">
                <input type="email" class="form-control" placeholder="Enter email..." name="email" required><br>
				</div>
			  <div class="col-12 input-group input-group-newsletter">
				<input type="password" class="form-control" placeholder="Enter password..." name="password" required><br>
                </div>
				<div class="col-12">
                  <button class="btn btn-block btn-lg btn-secondary" type="submit">Log In</button>
				</div>
				</div>
				</form>
				<?php
				if(isset($_SESSION['valid2']) && $_SESSION['valid2']==false){
						echo "<p> Email or password is wrong</p>";
						$_SESSION['valid2']=true;
				}
				if(isset($_SESSION['access'])&&$_SESSION['access']==false){
						echo "<p> Access denied</p>";
						$_SESSION['access']=true;
				}
				?>
				<p class="mb-1"><strong>OR</strong></p>
				<form class="login" action="register.php" method="POST" align="center">
				<div class="form-row">
					<div class="col-12">
						<input class="btn btn-block btn-lg btn-secondary" type="submit" value="Register" align="right">
					</div>
				</div>
				</form>
				</div>
				</div>
				</div>
            </div>
          </div>
        </div>
      </div>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/coming-soon.min.js"></script>

  </body>

</html>
