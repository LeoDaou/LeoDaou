<?php
session_start();
require('../../connection/db-info.php');
if(isset($_POST['email'])){
	$email = $mysqli->real_escape_string($_POST['email']);
}else{
	die("Don't try to mess around bro ;)");}
if(isset($_POST['password'])){
	$password = hash("sha256",$mysqli->real_escape_string($_POST['password']));
}else{
	die("Don't try to mess around bro ;)");}

$query = $mysqli->prepare("SELECT id FROM employees WHERE email = ? AND password = ?");
$query->bind_param('ss', $email, $password);
$query->execute();
$query->store_result();
$query->bind_result($id);
$query->fetch();
if($query->num_rows == 1){
		$_SESSION['logged_in'] = true;
		$_SESSION['id'] = $id;
		header('Location:user/');
}else{
	$_SESSION['valid1']=false;
	die("Email Does Not Exist");
}

?>