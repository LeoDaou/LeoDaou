<?php
require('../../connection/db-info.php');
session_start();
if(isset($_POST['password'])){
	$password = hash("sha256",$mysqli->real_escape_string($_POST['password']));
}else{
	die("Don't try to mess around bro ;)");}
$query = $mysqli->prepare("SELECT id FROM employees WHERE id=? AND password = ?");
$query->bind_param('is',$_SESSION['id'],$password);
$query->execute();
$query->store_result();
$query->bind_result($id);
$query->fetch();
if($query->num_rows == 1){
$_SESSION['user_log']=false;
$_SESSION['logged_in1']=false;
$_SESSION['id1']=null;
header('Location:../../');}
else{
$_SESSION['validity']=false;
header('Location:./');}

?>