<!DOCTYPE html>
<html lang="en">
<?php
session_start();
if(isset($_SESSION['logged_in1'])&&$_SESSION['logged_in1']==false)
	header('Location:../../');
?>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Coming Soon - Start Bootstrap Theme</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/coming-soon.min.css" rel="stylesheet">

  </head>

  <body style="background: url(https://www.rd.com/wp-content/uploads/2018/02/43_Walmart_Surprisingly-Simple-Ways-to-Save-BIG-at-the-Supermarket_186861932_Ken-Wolter-760x506.jpg) ; background-size: 100% 100%;">


    <div class="masthead">
      <div class="masthead-bg"></div>
      <div class="container h-100">
        <div class="row h-100">
          <div class="col-12 my-auto">
            <div class="masthead-content text-white text-center">
              <h1 class="mb-3">Welcome!</h1>
              <form class="login" action="register.php" method="POST">
			  <div class="col-12 input-group input-group-newsletter">
                <input type="email" class="form-control" placeholder="Enter email..." name="email" required><br>
				</div>
			  <div class="col-12 input-group input-group-newsletter">
				<input type="password" class="form-control" placeholder="Enter password..." name="password" required><br>
                </div>
				<div class="col-12">
                  <input class="btn btn-block btn-lg btn-secondary" type="submit" value="Log In" align="right">
				</div>
				<br>
				</form>
				<form class="login" action="back.php" method="POST">
				<div class="col-12 input-group input-group-newsletter">
				<input type="password" class="form-control" placeholder="Enter password..." name="password" required><br>
                </div>
				<div class="col-12">
                  <input class="btn btn-block btn-lg btn-secondary" type="submit" value="Back" align="right">
				</div>
				</form>
				<?php
				if(isset($_SESSION['validity1'])&&$_SESSION['validity1']==false){
					echo "Not gonna work";
				$_SESSION['validity1']=true;}
				?>
				<br>
				<form class="login" action="logout.php" method="POST">
				<div class="col-12 input-group input-group-newsletter">
				<input type="password" class="form-control" placeholder="Enter password..." name="password" required><br>
                </div>
				<div class="col-12">
                  <input class="btn btn-block btn-lg btn-secondary" type="submit" value="Log Out" align="right">
				</div>
				</form>
				<?php
				if(isset($_SESSION['validity'])&&$_SESSION['validity']==false){
					echo "Not gonna work";
				$_SESSION['validity']=true;}

				?>
            </div>
          </div>
        </div>
      </div>
	  </div>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/coming-soon.min.js"></script>

  </body>

</html>
