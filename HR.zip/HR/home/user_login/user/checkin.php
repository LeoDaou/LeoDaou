<?php
session_start();
require('../../../connection/db-info.php');
if(isset($_SESSION['check-in']) && $_SESSION['check-in']==true){
	$_SESSION['b']=false;
	header('Location:./');
}else{
if($_SESSION['logged_in'] == true){
	date_default_timezone_set('Asia/Beirut');
	$date = date('Y-m-d');
	$time = date('H:i:s');
	$query = $mysqli->prepare("INSERT INTO attendance (date,employee_id,start_time) VALUES(?,?,?)");
	$id=$_SESSION['id'];
	$query->bind_param('sis',$date,$id,$time);	
	$query->execute();
	$_SESSION['check-in']=true;
	$_SESSION['logged_in']=false;
	header('Location:../');
}
else{
	echo "Idiot";
header('Location:./');}
}

	
?>