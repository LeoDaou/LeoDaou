<?php
session_start();
require('../../../connection/db-info.php');
if(isset($_SESSION['check-out']) && $_SESSION['check-out']==true){
	echo "Idiot";
	header('Location:./');
}else{
	if(isset($_SESSION['check-in']) && $_SESSION['check-in']==true){
if($_SESSION['logged_in'] == true){
	date_default_timezone_set('Asia/Beirut');
	$date = date('Y-m-d');
	$time = date('H:i:s');
	$query=$mysqli->prepare("UPDATE attendance SET end_time=? WHERE employee_id=? AND date=?");
	$query->bind_param('sis',$time,$_SESSION['id'],$date);
	$query->execute();
	$_SESSION['check-out']=true;
	$_SESSION['logged_in']=false;
	header('Location:../');
}
else{
	header('Location:./');
}
}
else{
	$_SESSION['a']=false;
	header('Location:./');
}
}

	
?>