<!DOCTYPE html>
<html lang="en">
<?php
require('../../connection/db-info.php');
session_start();
if(isset($_SESSION['user_log'])&&$_SESSION['user_log']==true){
	header('Location:../user_login');
}
if(isset($_SESSION['logged_in1'])&&$_SESSION['logged_in1']==false)
	header('Location:../../');

?>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Viewing Employees</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/landing-page.min.css" rel="stylesheet">

  </head>

  <body>

  <nav class="navbar navbar-light bg-light static-top">
      <div class="container">
       <form class="register" action="back.php" method="POST">
		<button type="submit" class="btn btn-success">Back</button>
       </form>
	   <form class="register" action="logout.php" method="POST">
		<button type="submit" class="btn btn-success">Log Out</button>
       </form>
	  </div>
    </nav>
    <!-- Masthead -->
    <header class="masthead text-white text-center">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-xl-9 mx-auto">
            <h1 class="mb-5">Employees</h1>
          </div>
          <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
            <?php
			  $query=$mysqli->prepare("SELECT id,name,employee_type FROM employees");
			  $query->execute();
			  $query->store_result();
			  $query->bind_result($id,$name,$etype);
			  echo "<table border=\"l\" align=center>";
			  echo "<tr><td>ID</td><td>Name</td><td>Position</td><td>Type</td><td>Total Hours Worked</td><td>Wage</td></tr>";
			  while($query->fetch()){
				  $stmt=$mysqli->prepare("SELECT type,job_type,wage FROM emplyee_type WHERE id=?");
				  $stmt->bind_param('i',$etype);
				  $stmt->execute();
				  $stmt->store_result();
				  $stmt->bind_result($type,$jtype,$wag);
				  $stmt->fetch();
				  $stmt=$mysqli->prepare("SELECT job_type,start_time,end_time FROM job_type WHERE id=?");
				  $stmt->bind_param('i',$jtype);
				  $stmt->execute();
				  $stmt->store_result();
				  $stmt->bind_result($jobtype,$tstart,$tend);
				  $stmt->fetch();
				  $stmt=$mysqli->prepare("SELECT date,start_time,end_time FROM pastattendance WHERE employee_id=?");
				  $stmt->bind_param('i',$id);
				  $stmt->execute();
				  $stmt->store_result();
				  $stmt->bind_result($date,$start,$end);
				  $hours=0;
				  $sm=0;
				  while($stmt->fetch()){
					  $s=(int)substr($start,0,2);
					  $sm=(int)substr($start,3,5);
					  $sm=$sm/60;
					  $s=$s+$sm;
					$e=(int)substr($end,0,2);
					$em=(int)substr($end,3,4);
					$em=$em/60;
					$e=$em+$e;
					$hours=$hours+$e-$s;
				  }
				  $stmt=$mysqli->prepare("SELECT month FROM holiday WHERE month=?");
				  $a=(int)substr($date,5,6);
				  $stmt->bind_param('i',$a);
				  $stmt->execute();
				  $stmt->store_result();
				  $stmt->bind_result($month);
				  $stmt->fetch();
				  $rows=$stmt->num_rows;
				  $hour=(int)substr($tend,0,2)-(int)substr($tstart,0,2);
				  $row=$hour*$rows+4*$hour;
				  $w=30*$hour-$row;
				  $wa=$hours/$w;
				  $wage=$wa*$wag;
				  echo "<tr><td>".$id ."</td><td>".$name."</td><td>".$type."</td><td>".$jobtype."</td><td>".$hours."</td><td>".(int)$wage."</td></tr>";
			  }
			  echo "</table>";
			  ?>
			  </div>
          </div>
        </div>
      </div>
    </header>

    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
