<?php
header('Location:../');
?>