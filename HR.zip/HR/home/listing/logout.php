<?php
session_start();
$_SESSION['logged_in1']=false;
$_SESSION['id1']=null;
header('Location:../../');
?>