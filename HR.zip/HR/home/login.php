<?php
session_start();
$_SESSION['user_log']=true;
header('Location:user_login');
?>