<?php
session_start();
header('Location:../');

?>