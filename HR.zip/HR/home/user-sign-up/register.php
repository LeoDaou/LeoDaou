<?php
session_start();
require('../../connection/db-info.php');
if(isset($_POST['email'])){
	$email = $mysqli->real_escape_string($_POST['email']);
}else{
	die("Don't try to mess around bro ;)");}
if(isset($_POST['password'])){
	$password = hash("sha256",$mysqli->real_escape_string($_POST['password']));
}else{
	die("Don't try to mess around bro ;)");}
if(isset($_POST['name'])){
	$name = $mysqli->real_escape_string($_POST['name']);
}else{
	die("Don't try to mess around bro ;)");} 
if(isset($_POST['employee_type'])){
	$employee_type = $mysqli->real_escape_string($_POST['employee_type']);
}else{
	die("Don't try to mess around bro ;)");} 
if(isset($_POST['job_type'])){
	$job_type = $mysqli->real_escape_string($_POST['job_type']);
}else{
	die("Don't try to mess around bro ;)");} 
	
$query = $mysqli->prepare("SELECT id FROM job_type WHERE job_type=?");
$query->bind_param('s', $job_type);
$query->execute();
$query->store_result();
$query->bind_result($id1);
$query->fetch();	

if($query->num_rows ==0){
	$_SESSION['validtype']=false;
	header('Location:index.php');
}
else{
$query = $mysqli->prepare("SELECT id FROM emplyee_type WHERE type=? AND job_type=?");
$query->bind_param('si', $employee_type, $id1);
$query->execute();
$query->store_result();
$query->bind_result($id2);
$query->fetch();

if($query->num_rows ==0){
	$_SESSION['validtype1']=false;
	header('Location:index.php');
}
else{
$query = $mysqli->prepare("SELECT id FROM employees WHERE email = ? AND password = ?");
$query->bind_param('ss', $email, $password);
$query->execute();
$query->store_result();
$query->bind_result($id);
$query->fetch();

if($query->num_rows == 0){
		$_SESSION['valid4']=true;
		$query = $mysqli->prepare("INSERT INTO employees (email,password,name,employee_type) Values(?,?,?,?)");
		$query->bind_param('sssi',$email,$password,$name,$id2);
		$query->execute();
		header('Location:../');}
else{
	$_SESSION['valid4']=false;
	header('Location:index.php');
}}}


?>