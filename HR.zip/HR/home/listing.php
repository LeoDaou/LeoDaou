<?php
header('Location:listing/');
?>