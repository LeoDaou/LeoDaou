<?php
header('Location:user-sign-up');
?>