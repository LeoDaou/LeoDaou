<?php
session_start();
require('../connection/db-info.php');
if(isset($_POST['email'])){
	$email = $mysqli->real_escape_string($_POST['email']);
}else{
	die("Don't try to mess around bro ;)");}
if(isset($_POST['password'])){
	$password = hash("sha256",$mysqli->real_escape_string($_POST['password']));
}else{
	die("Don't try to mess around bro ;)");}
if(isset($_POST['name'])){
	$name = $mysqli->real_escape_string($_POST['name']);
}else{
	die("Don't try to mess around bro ;)");} 


$query = $mysqli->prepare("SELECT id FROM employees WHERE email = ? AND password = ?");
$query->bind_param('ss', $email, $password);
$query->execute();
$query->store_result();
$query->bind_result($id);
$query->fetch();

if($query->num_rows == 0){
		$_SESSION['valid']=true;
		$query = $mysqli->prepare("INSERT INTO employees (email,password,name,employee_type) Values(?,?,?,?)");
		$a=1;
		$query->bind_param('sssi',$email,$password,$name,$a);
		$query->execute();
		header('Location:../');}
else{
	$_SESSION['valid']=false;
	header('Location:index.php');
}


?>