<!DOCTYPE html>
<html lang="en">
<?php
session_start();
if(isset($_SESSION['user_log'])&&$_SESSION['user_log']==true){
header('Location:../home/user_login');}

?>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Coming Soon - Start Bootstrap Theme</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,900i" rel="stylesheet">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/coming-soon.min.css" rel="stylesheet">

  </head>

  <body style="background: url(https://www.rd.com/wp-content/uploads/2018/02/43_Walmart_Surprisingly-Simple-Ways-to-Save-BIG-at-the-Supermarket_186861932_Ken-Wolter-760x506.jpg) ; background-size: 100% 100%;">
	

    <div class="masthead">
      <div class="masthead-bg"></div>
      <div class="container h-100">
        <div class="row h-100">
          <div class="col-12 my-auto">
            <div class="masthead-content text-white text-center">
              <h1 class="mb-3">Sign up!</h1>
              <form class="login" action="register.php" method="POST">
			  <div class="col-12 input-group input-group-newsletter">
                <input type="email" class="form-control" placeholder="Enter email..." name="email" required><br>
				</div>
			  <div class="col-12 input-group input-group-newsletter">
				<input type="password" class="form-control" placeholder="Enter password..." name="password" required><br>
                </div>
				<div class="col-12 input-group input-group-newsletter">
				<input type="name" class="form-control" placeholder="Enter name..." name="name" required><br>
                </div>	
				<div class="col-12">
                  <button class="btn btn-block btn-lg btn-secondary" type="submit">Sign up</button>
				</div>
				</form>
				<?php
				if(isset($_SESSION['valid']) && $_SESSION['valid']==false){
						echo "<p> Email already exists </p>";
						$_SESSION['valid']=true;
				}
				?>
				<br>
				<form class="redirect" action="back.php" method="POST">
				<div class="col-12">
                  <button class="btn btn-block btn-lg btn-secondary" type="submit">Back</button>
				</div>
				</form>
				</div>
				</div>
				</div>
            </div>
          </div>
        </div>
      </div>


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/coming-soon.min.js"></script>

  </body>

</html>
