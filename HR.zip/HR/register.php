<?php
header('Location:sign-up');
?>