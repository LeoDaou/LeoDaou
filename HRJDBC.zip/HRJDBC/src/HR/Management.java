package HR;
import java.sql.*;
import java.security.MessageDigest;
import java.time.format.DateTimeFormatter;  

import javax.xml.bind.DatatypeConverter;

import java.time.LocalDateTime;    
import java.util.Scanner;

public class Management {
	public static String getHash(byte[] inputBytes, String algorithm){
		String hashValue="";
		try{
			MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
			messageDigest.update(inputBytes);
			byte[] digestedBytes=messageDigest.digest();
			hashValue=DatatypeConverter.printHexBinary(digestedBytes).toLowerCase();
		}
		catch(Exception e){
			
		}
		return hashValue;
		
		
	}
	public void menu2 (){
		System.out.println("1-Check In");
		System.out.println("2-Check Out");
		System.out.println("3-Back");
		System.out.println("----------------");
		System.out.println("Choose");
	}
	public void menu (){
		System.out.println("1-Add Employees");
		System.out.println("2-Delete Employees");
		System.out.println("3-Update Employees");
		System.out.println("4-View Employees");
		System.out.println("5-Checking");
		System.out.println("6-Close and Log Out");
		System.out.println("----------------");
		System.out.println("Choose");
	}
	public boolean add(java.sql.Connection conn){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter name");
		String name=scan.next();
		System.out.println(name);
		System.out.println("Enter email");
		String email=scan.next();
		System.out.println("Enter password");
		String password=scan.next();
		password = getHash(password.getBytes(), "SHA-256");
		System.out.println("Enter position");
		String position=scan.next();
		System.out.println("Enter type");
		String type=scan.next();
		type+=scan.nextLine();
		String sql=null;
		ResultSet rs=null;
		Statement stmt=null;
		try {
			stmt=conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sql="Select * from employees where email ='"+ email +"'";
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(!rs.next()){
				sql="Select * from job_type where job_type ='"+ type +"'";
				ResultSet ds=null;
				ds=stmt.executeQuery(sql);
				if(ds.next()){
				sql="Select * from emplyee_type where job_type ='"+ ds.getString("id") +"'"+"and type ='"+position+"'";
				ResultSet ss=null;
				ss=stmt.executeQuery(sql);
				if(ss.next()){
					System.out.println(ss.getInt("id"));
				sql="Insert into employees (name,email,password,employee_type) Values('"+name+"','"+email+"','"+password+"',"+ss.getInt("id")+")";
				stmt.executeUpdate(sql);
				}}}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean delete(java.sql.Connection conn){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter email");
		String email=scan.next();
		String sql=null;
		ResultSet rs=null;
		Statement stmt=null;
		try {
			stmt=conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sql="Select * from employees where email ='"+ email +"'";
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(rs.next()){
				sql="Delete from employees where email='"+email+"'";
				stmt.executeUpdate(sql);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public boolean update(java.sql.Connection conn){
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter email");
		String email=scan.next();
		System.out.println("Enter updated position");
		String position=scan.next();
		System.out.println("Enter type");
		String type=scan.next();
		type=scan.nextLine();
		String sql=null;
		ResultSet rs=null;
		Statement stmt=null;
		try {
			stmt=conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sql="Select * from employees where email ='"+ email +"'";
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(!rs.next()){
				sql="Select * from job_type where job_type ='"+ type +"'";
				ResultSet ds=null;
				ds=stmt.executeQuery(sql);
				if(ds.next()){
				sql="Select * from emplyee_type where job_type ='"+ ds.getString("id") +"'"+"and type ='"+position+"'";
				ResultSet ss=null;
				ss=stmt.executeQuery(sql);
				if(ss.next()){
					System.out.println(ss.getInt("id"));
				sql="Update employees Set employee_type='"+ss.getInt("id")+"' where email='"+email+"'";
				stmt.executeUpdate(sql);
				}}}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	public void view(java.sql.Connection conn){
		String sql=null;
		sql="Select * from employees";
		ResultSet rs=null;
		Statement stmt=null;
		try {
			stmt=conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Name\tEmail\tPosition\tType");
			while(rs.next()){
				sql="Select * from emplyee_type where id ='"+ rs.getInt("employee_type") +"'";
				ResultSet ds=null;
				Statement stmt1=null;
				try {
					stmt1=conn.createStatement();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ds=stmt1.executeQuery(sql);
				if(ds.next()){
				sql="Select * from job_type where id ='"+ ds.getString("job_type") +"'";
				ResultSet ss=null;
				Statement stmt2=null;
				try {
					stmt2=conn.createStatement();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				ss=stmt2.executeQuery(sql);
				if(ss.next()){
					sql="Select * from pastattendance where employee_id='"+rs.getInt("id")+"'";
					ResultSet rs1=null;
					Statement stmt4=null;
					stmt4=conn.createStatement();
					rs1=stmt4.executeQuery(sql);
					double hours=0;
					double sh;
					double eh;
					double smins;
					double emins;
					while(rs1.next()){
						sh=Integer.parseInt(rs1.getString("start_time").substring(0,2));
						eh=Integer.parseInt(rs1.getString("end_time").substring(0,2));
						smins=(double)(Integer.parseInt(rs1.getString("start_time").substring(3,5)))/60;
						emins=(double)(Integer.parseInt(rs1.getString("end_time").substring(3,5)))/60;
						eh=eh+emins;
						sh=sh+smins;
						hours=hours+(eh-sh);
					}
					sql="Select * from holiday";
					rs1=null;
					stmt4=null;
					stmt4=conn.createStatement();
					rs1=stmt4.executeQuery(sql);
					rs1.last();
					int count=rs1.getRow();
					int days=30-count-4;
					int start=Integer.parseInt(ss.getString("start_time").substring(0,2));
					int end=Integer.parseInt(ss.getString("end_time").substring(0,2));
					int h=end-start;
					double ho=h*days;
					Double wage=ds.getDouble("wage")*(hours/ho);
					System.out.println(rs.getString("name")+"\t"+rs.getString("email")+"\t"+ds.getString("type")+"\t"+ss.getString("job_type")+"\t"+wage+"\t"+hours+"\t"+ho);
				}
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void checking(String email,String password,java.sql.Connection conn){
		menu2();
		Scanner scan= new Scanner(System.in);
		int choice=scan.nextInt();
		if(choice==1){
			DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
			LocalDateTime dnow = LocalDateTime.now();
			DateTimeFormatter time = DateTimeFormatter.ofPattern("HH:mm:ss");  
			LocalDateTime tnow = LocalDateTime.now();
			
			String sql=null;;
			ResultSet rs=null;
			Statement stmt=null;		
			try {
				stmt=conn.createStatement();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			sql="Select * from employees where email ='"+ email +"'";
			try {
				rs=stmt.executeQuery(sql);
				rs.next();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			ResultSet rs2=null;
			Statement stmt2=null;		
			try {
				stmt2=conn.createStatement();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}				
			String sql1=null;

			try {
				sql1="Select * from attendance where employee_id='"+rs.getInt("id")+"' and date='"+date.format(dnow)+"'";
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				rs2=stmt2.executeQuery(sql1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				if(rs2.next()){
				System.out.println("out with you");
				}
				else{
				sql="Insert into attendance (date,employee_id,start_time,end_time) Values('"+date.format(dnow)+"','"+rs.getInt("id")+"','"+time.format(tnow)+"','00:00:00')";
				Statement stmt3=conn.createStatement();
				stmt3.executeUpdate(sql);}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(choice==2){
			DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
			LocalDateTime dnow = LocalDateTime.now();
			DateTimeFormatter time = DateTimeFormatter.ofPattern("HH:mm:ss");  
			LocalDateTime tnow = LocalDateTime.now();
			
			String sql=null;;
			ResultSet rs=null;
			Statement stmt=null;		
			try {
				stmt=conn.createStatement();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			sql="Select * from employees where email ='"+ email +"'";
			try {
				rs=stmt.executeQuery(sql);
				rs.next();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			ResultSet rs2=null;
			Statement stmt2=null;		
			try {
				stmt2=conn.createStatement();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}				
			String sql1=null;

			try {
				sql1="Select * from attendance where employee_id='"+rs.getInt("id")+"' and date='"+date.format(dnow)+"'";
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				rs2=stmt2.executeQuery(sql1);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				if(rs2.next()){
				if(!rs2.getString("end_time").equals("00:00:00"))
						System.out.println(rs2.getString("out with you"));
				
				else{
				sql="Update attendance Set end_time='"+time.format(tnow)+"' where employee_id='"+rs.getInt("id")+"' and date='"+date.format(dnow)+"'";
				Statement stmt3=conn.createStatement();
				stmt3.executeUpdate(sql);}}
				else
					System.out.println("Out with you");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
		}
		if(choice==3){
			return;
		}}
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		Statement stmt=null;
		java.sql.Connection conn = null;
		String sql=null;
		ResultSet rs=null;
		Scanner scan = new Scanner(System.in);
		conn= DriverManager.getConnection("jdbc:mysql://localhost/hr","root",""	);
		stmt=conn.createStatement();
		System.out.println("Enter email");
		String email=scan.next();
		System.out.println("Enter your password");
		String password=scan.next();
		password = getHash(password.getBytes(), "SHA-256");
		sql="Select * from employees where email ='"+ email +"' and employee_type=1";
		rs=stmt.executeQuery(sql);
		boolean canEnter=false;
		do{
			if(rs.next()){
				if(rs.getString("password").equals(password))
					canEnter=true;
				else {
					System.out.println("wrong pass");
					System.out.println("Enter again");
					System.out.println("Enter email");
					email=scan.next();
					System.out.println("Enter your password");
					password=scan.next();
					password = getHash(password.getBytes(), "SHA-256");
					sql="Select * from employees where email ='"+ email +"' and employee_type=1";
					rs=stmt.executeQuery(sql);
				}
		}else{
			System.out.println("11");
			System.out.println("Enter again");
			System.out.println("Enter email");
			email=scan.next();
			System.out.println("Enter your password");
			password=scan.next();
			password = getHash(password.getBytes(), "SHA-256");
			sql="Select * from employees where email ='"+ email +"' and employee_type=1";
			rs=stmt.executeQuery(sql);
		}
			}while(canEnter==false);
		DateTimeFormatter date = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
		LocalDateTime dnow = LocalDateTime.now();
		if(date.format(dnow).substring(8,10).equals("01")){
			sql="TRUNCATE TABLE pastattendance";
			ResultSet rs1=null;
			Statement stmt1=null;
			stmt1=conn.createStatement();
			stmt1.executeUpdate(sql);
			sql="Select * from attendance";
			rs1=null;
			stmt1=null;
			stmt1=conn.createStatement();
			rs1=stmt1.executeQuery(sql);
			while(rs1.next()){
				sql="Insert Into pastattendance (date,employee_id,strat_time,end_time) Values('"+rs1.getString("date")+"',"+rs1.getInt("id")+",'"+rs1.getString("start_time")+"','"+rs1.getString("edn_time")+"'";
				Statement stmt2=null;
				stmt2=conn.createStatement();
				stmt2.executeUpdate(sql);
			}
			
		}
		Management m= new Management();
		int choice;
		do{
		m.menu();
		 choice=scan.nextInt();
		if(choice==1){
			m.add(conn);
		}
		if(choice==2){
			m.delete(conn);
		}
		if(choice==3){
			m.update(conn);
		}
		if(choice==4){
			m.view(conn);
		}
		if(choice==5){
			System.out.println("Enter email");
			email=scan.next();
			System.out.println("Enter password");
			password=scan.next();
			password = getHash(password.getBytes(), "SHA-256");
			sql="Select * from employees where email ='"+ email +"'";
			rs=stmt.executeQuery(sql);
			if(rs.next()){
				if(rs.getString("password").equals(password))
					m.checking(email,password,conn);
				else 
					System.out.println("wrong pass");
		}
		}
		if(choice==6){
			System.out.println("Logging Out");
			return;
		}
		if(choice<0||choice>6){
			System.out.println("Choose again");
			choice=1;
		}
		}
		while(choice>0 && choice<6);
		
	}
}
